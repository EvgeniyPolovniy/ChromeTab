Cryptocoins
===========

Cryptocoins is free vector/webfont iconpack of your favourite cryptocurrencies.

Available both in pure vector SVG and webfont formats for taking advantage of small file sizes and unlimited scalability, Cryptocoins are perfect for usage on the web – right where they belong. Use them all or just the ones you need.

- Cryptocoins homepage: https://allienworks.net/products/cryptocoins
- Demo page: http://labs.allienworks.net/icons/cryptocoins
- Official GitHub repo: https://github.com/allienworks/cryptocoins

Donate crypto and support further development:
https://github.com/allienworks/cryptocoins#author


Author
------

Martin Allien

- Website: https://allienworks.net
- Keybase: https://keybase.io/martin_allien
- Twitter: https://twitter.com/AllienWorks
- Google+: https://google.com/+AllienWorksNet


Licence
-------

Released under GNU GPL v2.0